// Minimal interactivity: nav toggle, smooth scroll, form handling, dynamic year
document.addEventListener('DOMContentLoaded', function() {
  // year
  const yearEl = document.getElementById('year');
  if (yearEl) yearEl.textContent = new Date().getFullYear();

  // mobile nav toggle
  const navToggle = document.querySelector('.nav-toggle');
  const nav = document.querySelector('.nav');
  navToggle?.addEventListener('click', () => {
    const expanded = navToggle.getAttribute('aria-expanded') === 'true';
    navToggle.setAttribute('aria-expanded', String(!expanded));
    nav?.classList.toggle('open');
  });

  // smooth scroll for local links
  document.querySelectorAll('a[href^="#"]').forEach(a=>{
    a.addEventListener('click', function(e){
      const target = document.querySelector(this.getAttribute('href'));
      if (target) {
        e.preventDefault();
        target.scrollIntoView({behavior:'smooth', block:'start'});
        // close mobile nav if open
        if (nav?.classList.contains('open')) {
          nav.classList.remove('open');
          navToggle?.setAttribute('aria-expanded','false');
        }
      }
    });
  });

  // contact form handling (client-only demo)
  const contactForm = document.getElementById('contactForm');
  const formMessage = document.getElementById('formMessage');
  contactForm?.addEventListener('submit', function(e){
    e.preventDefault();
    const form = new FormData(contactForm);
    const name = form.get('name')?.toString().trim();
    const email = form.get('email')?.toString().trim();
    const message = form.get('message')?.toString().trim();

    // basic validation
    if (!name || !email || !message) {
      showMessage('Mohon isi semua bidang sebelum mengirim.', true);
      return;
    }
    // simulate submit
    showMessage('Mengirim...', false);
    setTimeout(() => {
      contactForm.reset();
      showMessage('Terima kasih! Pesan Anda telah dikirim. Saya akan menghubungi Anda segera.', false);
    }, 900);

    function showMessage(text, isError) {
      if (!formMessage) return;
      formMessage.hidden = false;
      formMessage.textContent = text;
      formMessage.style.color = isError ? '#d64545' : '';
    }
  });
});